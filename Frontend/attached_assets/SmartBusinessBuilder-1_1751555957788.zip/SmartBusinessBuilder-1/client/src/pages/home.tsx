import { IntroPanel } from "@/components/IntroPanel";

export default function Home() {
  return <IntroPanel />;
}
