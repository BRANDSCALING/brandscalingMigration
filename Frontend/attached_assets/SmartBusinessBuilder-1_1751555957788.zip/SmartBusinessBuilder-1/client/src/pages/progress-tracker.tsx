import { Module6_ProgressTracker } from "@/components/Module6_ProgressTracker";

export default function ProgressTracker() {
  return <Module6_ProgressTracker />;
}