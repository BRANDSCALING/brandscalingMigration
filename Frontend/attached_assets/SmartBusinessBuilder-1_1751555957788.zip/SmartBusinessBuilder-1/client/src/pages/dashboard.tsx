import { DashboardPanel } from "@/components/DashboardPanel";

export default function Dashboard() {
  return <DashboardPanel />;
}