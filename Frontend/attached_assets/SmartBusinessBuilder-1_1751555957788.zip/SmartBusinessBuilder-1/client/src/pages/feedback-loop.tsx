import { Module5_FeedbackLoop } from "@/components/Module5_FeedbackLoop";

export default function FeedbackLoop() {
  return <Module5_FeedbackLoop />;
}