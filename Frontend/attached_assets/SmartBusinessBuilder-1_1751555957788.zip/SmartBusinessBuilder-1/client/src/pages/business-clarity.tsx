import { Module1_BusinessClarity } from "@/components/Module1_BusinessClarity";

export default function BusinessClarity() {
  return <Module1_BusinessClarity />;
}