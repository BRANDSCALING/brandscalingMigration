import { ModelOutputPanel } from "@/components/ModelOutputPanel";

export default function ModelOutput() {
  return <ModelOutputPanel />;
}