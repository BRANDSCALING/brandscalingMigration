import { Module3_ProductDesign } from "@/components/Module3_ProductDesign";

export default function ProductDesign() {
  return <Module3_ProductDesign />;
}