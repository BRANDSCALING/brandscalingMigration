import { Module4_GoToMarket } from "@/components/Module4_GoToMarket";

export default function GoToMarket() {
  return <Module4_GoToMarket />;
}